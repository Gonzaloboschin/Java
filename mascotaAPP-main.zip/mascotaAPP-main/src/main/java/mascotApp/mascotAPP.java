package mascotApp;

import Mascota_Entidades.Mascota;
import Mascota_Entidades.Usuario;
import Mascota_Enumeraciones.Raza;
import Mascota_Enumeraciones.SexoHumano;
import Mascota_Servicios.ServicioMascota;
import java.util.ArrayList;
import java.util.Scanner;


public class mascotAPP {
    
    public static void main(String[] args) {
        
        System.out.println(Raza.BEAGLE.toString());
    }
    
}
