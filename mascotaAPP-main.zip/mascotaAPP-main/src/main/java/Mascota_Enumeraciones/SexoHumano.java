package Mascota_Enumeraciones;

public enum SexoHumano {
    HOMBRE, MUJER, OTRO;
}
